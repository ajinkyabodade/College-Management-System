--
-- Database: `collegemanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `branch` varchar(40) NOT NULL,
  `year` varchar(20) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `date` varchar(20) NOT NULL,
  `rollno` varchar(20) NOT NULL,
  `attend` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `branch`, `year`, `subject`, `date`, `rollno`, `attend`) VALUES
(440, 'Civil Engineering', 'Second Year', 'ED', '1997-11-19', '1', 'p'),
(441, 'Civil Engineering', 'Second Year', 'ED', '1997-11-19', '1', 'p'),
(442, 'Civil Engineering', 'Second Year', 'ED', '1997-11-19', '1', 'p'),
(443, 'Civil Engineering', 'Second Year', 'ED', '1997-11-19', '4', 'p'),
(444, 'Civil Engineering', 'Second Year', 'ED', '1997-11-19', '5', 'p'),
(445, 'Civil Engineering', 'Second Year', 'ED', '1997-11-19', '6', 'p'),
(446, 'Civil Engineering', 'Second Year', 'ED', '1997-11-19', '7', 'p'),
(447, 'Civil Engineering', 'Second Year', 'ED', '1997-11-19', '8', 'p'),
(448, 'Computer Science', 'First Year', 'PM', '8798-12-04', '1', 'p'),
(449, 'Computer Science', 'First Year', 'PM', '8798-12-04', '2', 'p'),
(450, 'Computer Science', 'First Year', 'PM', '8798-12-04', '5', 'p'),
(451, 'Computer Science', 'First Year', 'PM', '8798-12-04', '50', 'p'),
(452, 'Computer Science', 'First Year', 'PM', '8798-12-04', '1', 'p'),
(453, 'Computer Science', 'First Year', 'PM', '8798-12-04', '2', 'p'),
(454, 'Computer Science', 'First Year', 'PM', '8798-12-04', '5', 'p'),
(455, 'Computer Science', 'First Year', 'PM', '8798-12-04', '50', 'p');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `year` varchar(30) NOT NULL,
  `teachern` varchar(30) NOT NULL,
  `sub` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `q1` varchar(30) NOT NULL,
  `q2` varchar(30) NOT NULL,
  `q3` varchar(30) NOT NULL,
  `q4` varchar(30) NOT NULL,
  `q5` varchar(30) NOT NULL,
  `q6` varchar(30) NOT NULL,
  `q7` varchar(30) NOT NULL,
  `q8` varchar(30) NOT NULL,
  `q9` varchar(30) NOT NULL,
  `q10` varchar(30) NOT NULL,
  `q11` varchar(30) NOT NULL,
  `q12` varchar(30) NOT NULL,
  `q13` varchar(30) NOT NULL,
  `q14` varchar(30) NOT NULL,
  `q15` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `branch`, `year`, `teachern`, `sub`, `date`, `q1`, `q2`, `q3`, `q4`, `q5`, `q6`, `q7`, `q8`, `q9`, `q10`, `q11`, `q12`, `q13`, `q14`, `q15`) VALUES
(1, 'Computer Science', 'Second Year', 'AOB', 'DS', '', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never'),
(2, 'Computer Science', 'Second Year', 'AOB', 'DS', '', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never'),
(3, 'Computer Science', 'First Year', 'AOB', 'DS', '', 'Always', 'Rarely', 'Always', 'Never', 'Sometime', 'Never', 'Rarely', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never'),
(4, 'Computer Science', 'First Year', 'AOB', 'DS', '1211-12-12', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never', 'Never');

-- --------------------------------------------------------

--
-- Table structure for table `flogin`
--

CREATE TABLE `flogin` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flogin`
--

INSERT INTO `flogin` (`id`, `userid`, `password`) VALUES
(2, 'plitstaff', 'staff@plit');

-- --------------------------------------------------------

--
-- Table structure for table `newsandevents`
--

CREATE TABLE `newsandevents` (
  `id` int(11) NOT NULL,
  `ns` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsandevents`
--

INSERT INTO `newsandevents` (`id`, `ns`) VALUES
(1, 'jhgfjhdkh');

-- --------------------------------------------------------

--
-- Table structure for table `plogin`
--

CREATE TABLE `plogin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plogin`
--

INSERT INTO `plogin` (`id`, `username`, `password`) VALUES
(1, 'principal', '123');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `year` varchar(30) NOT NULL,
  `emailid` varchar(80) NOT NULL,
  `linkinid` varchar(50) NOT NULL,
  `studentid` varchar(30) NOT NULL,
  `rollno` varchar(20) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mobno` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `branch`, `year`, `emailid`, `linkinid`, `studentid`, `rollno`, `dob`, `address`, `mobno`, `username`, `password`) VALUES
(2, 'Ajinkya Pandurang Bodade', 'Computer Science', 'Second Year', 'bodadeajinkya@gmail.com', 'ajinkyabodade.3', 'PBE1564687', '01', '1997-11-19', 'Shri Nagar', '9527491071', 'ajinkyabo', '123'),
(3, 'Ajinkya Pandurang Bodade', 'Computer Science', 'Second Year', 'bodadeajinkya@gmail.com', 'ajinkyabodade.3', 'PBE1564687', '01', '1997-11-19', 'Shri Nagar', '9422881102', 'ajinkyabo', '123');

-- --------------------------------------------------------

--
-- Table structure for table `suggestion`
--

CREATE TABLE `suggestion` (
  `id` int(11) NOT NULL,
  `rs` varchar(1000) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suggestion`
--

INSERT INTO `suggestion` (`id`, `rs`, `date`) VALUES
(1, 'optical mouse scroll wheel optical sensor comfort griip sleek design', '0000-00-00'),
(2, 'asfasfasas a a f as a af afffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `tgform1`
--

CREATE TABLE `tgform1` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `branch` varchar(20) NOT NULL,
  `year` varchar(10) NOT NULL,
  `emailid` varchar(30) NOT NULL,
  `linkid` varchar(20) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `mobs` varchar(12) NOT NULL,
  `mobf` varchar(12) NOT NULL,
  `pname` varchar(30) NOT NULL,
  `padd` varchar(60) NOT NULL,
  `year1` varchar(10) NOT NULL,
  `per1` varchar(10) NOT NULL,
  `spass1` varchar(50) NOT NULL,
  `year2` varchar(10) NOT NULL,
  `per2` varchar(10) NOT NULL,
  `spass2` varchar(60) NOT NULL,
  `year3` varchar(10) NOT NULL,
  `per3` varchar(10) NOT NULL,
  `spass3` varchar(60) NOT NULL,
  `year4` varchar(10) NOT NULL,
  `per4` varchar(10) NOT NULL,
  `spass4` varchar(60) NOT NULL,
  `year5` varchar(10) NOT NULL,
  `per5` varchar(10) NOT NULL,
  `spass5` varchar(60) NOT NULL,
  `year6` varchar(10) NOT NULL,
  `per6` varchar(10) NOT NULL,
  `spass6` varchar(60) NOT NULL,
  `year7` varchar(10) NOT NULL,
  `per7` varchar(10) NOT NULL,
  `spass7` varchar(60) NOT NULL,
  `year8` varchar(10) NOT NULL,
  `per8` varchar(10) NOT NULL,
  `spass8` varchar(60) NOT NULL,
  `year9` varchar(10) NOT NULL,
  `per9` varchar(10) NOT NULL,
  `spass9` varchar(50) NOT NULL,
  `year10` varchar(10) NOT NULL,
  `per10` varchar(10) NOT NULL,
  `spass10` varchar(50) NOT NULL,
  `year11` varchar(10) NOT NULL,
  `per11` varchar(10) NOT NULL,
  `spass11` varchar(50) NOT NULL,
  `fedu` varchar(20) NOT NULL,
  `focc` varchar(20) NOT NULL,
  `medu` varchar(20) NOT NULL,
  `mocc` varchar(20) NOT NULL,
  `inc` varchar(20) NOT NULL,
  `fpro` varchar(20) NOT NULL,
  `yer12` varchar(10) NOT NULL,
  `roll1` varchar(10) NOT NULL,
  `tgn` varchar(30) NOT NULL,
  `yer13` varchar(10) NOT NULL,
  `roll2` varchar(10) NOT NULL,
  `tgn1` varchar(30) NOT NULL,
  `yer14` varchar(10) NOT NULL,
  `roll3` varchar(10) NOT NULL,
  `tgn2` varchar(30) NOT NULL,
  `yer15` varchar(10) NOT NULL,
  `roll4` varchar(10) NOT NULL,
  `tgn3` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `unittest`
--

CREATE TABLE `unittest` (
  `id` int(11) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `sem` varchar(30) NOT NULL,
  `utno` varchar(10) NOT NULL,
  `rollno` varchar(20) NOT NULL,
  `sub1` varchar(40) NOT NULL,
  `sub1o` varchar(40) NOT NULL,
  `sub2` varchar(40) NOT NULL,
  `sub2o` varchar(40) NOT NULL,
  `sub3` varchar(40) NOT NULL,
  `sub3o` varchar(40) NOT NULL,
  `sub4` varchar(40) NOT NULL,
  `sub4o` varchar(40) NOT NULL,
  `sub5` varchar(40) NOT NULL,
  `sub5o` varchar(40) NOT NULL,
  `sub6` varchar(40) NOT NULL,
  `sub6o` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unittest`
--

INSERT INTO `unittest` (`id`, `branch`, `sem`, `utno`, `rollno`, `sub1`, `sub1o`, `sub2`, `sub2o`, `sub3`, `sub3o`, `sub4`, `sub4o`, `sub5`, `sub5o`, `sub6`, `sub6o`) VALUES
(64, 'Computer Science', 'First Semester', '1', '1', '1', '12', '12', '12', '12', '12', '12', '21', '21', '21', '21', '21'),
(65, 'Computer Science', 'First Semester', '1', '21', '21', '21', '21', '21', '21', '21', '2', '12', '12', '12', '12', '12'),
(66, 'Computer Science', 'First Semester', '1', '12', '12', '12', '12', '12', '1', '21', '21', '21', '2', '12', '12', '12'),
(67, 'Computer Science', 'First Semester', '1', '12', '12', '12', '12', '1', '21', '21', '21', '21', '2', '12', '12', '1'),
(68, 'Computer Science', 'First Semester', '1', '21', '21', '2', '1', '211', '21', '21', '21', '21', '21', '2', '121', '21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flogin`
--
ALTER TABLE `flogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsandevents`
--
ALTER TABLE `newsandevents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plogin`
--
ALTER TABLE `plogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suggestion`
--
ALTER TABLE `suggestion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tgform1`
--
ALTER TABLE `tgform1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unittest`
--
ALTER TABLE `unittest`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=456;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `flogin`
--
ALTER TABLE `flogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `newsandevents`
--
ALTER TABLE `newsandevents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `plogin`
--
ALTER TABLE `plogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `suggestion`
--
ALTER TABLE `suggestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tgform1`
--
ALTER TABLE `tgform1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `unittest`
--
ALTER TABLE `unittest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
